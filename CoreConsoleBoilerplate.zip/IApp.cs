﻿namespace $safeprojectname$
{
    public interface IApp
    {
        void Run();
    }
}